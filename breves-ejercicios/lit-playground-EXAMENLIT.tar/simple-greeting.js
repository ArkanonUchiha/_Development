import {html, css, LitElement} from 'lit';

export class SimpleGreeting extends LitElement {
  static styles = css`* { color: blue }`;

  static properties = {
    name: {type: String},
    nameF: { type: String, attribute: 'fullname' },
    personOBJ: { type: Object },
    personObjERROR: { type: Object },
    personsARR: { type: Array },
    personsArrERROR: { type: Array },
    state: { type: Object },
    colors: { type: Array}
  }

  constructor() {
    super();
    this.name = 'Somebody';
    this.nameF = '';
    this.personOBJ = {};
    this.personObjERROR = {};
    this.personsARR = [];
    this.personsArrERROR = [];
    this.state = { seconds: 0 };
    this.interval = setInterval(() => (this.state = {
      seconds: this.state.seconds + 1
    }), 1000);
    this.colors = ['Rojo', 'Verde', 'Negro', 'Azul'];
  }

  render() {
    console.log(
        this.nameF,
        this.personOBJ,
        this.personObjERROR,
        this.personsARR,
        this.personsArrERROR,
        this.state,
        this.interval,
        this.colors
    );

    return html`
        <p>nameF: ${this.nameF}</p>
        <p>personOBJ: ${this.personOBJ}</p>
        <p>personObjERROR: ${this.personObjERROR}</p>
        <p>personsARR: ${this.personsARR}</p>
        <p>personsArrERROR: ${this.personsArrERROR}</p>
        <p>Count: ${this.state.seconds}</p>
        <ul>
          Colors:
          ${this.colors.map(color =>
            html`<li style="color: ${color}">${color}</li>`
          )}
        </ul>
    `;
  }
}
customElements.define('simple-greeting', SimpleGreeting);
